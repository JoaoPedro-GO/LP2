﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        Double SalBruto, SalLiquido, NumFilhos, DescontoINSS;

        private void mskboxSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskboxSalBruto.Text, out SalBruto))
            {
                MessageBox.Show("Insira apenas numeros para o Salário Bruto");
                mskboxSalBruto.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
              //  SalBruto = double.Parse(mskboxSalBruto.Text);
                NumFilhos = Convert.ToDouble(nupFilhos.Value);

                if (SalBruto > 0 & SalBruto <= 800.47)
                {
                    txtAliINSS.Text = "7.98%";
                    DescontoINSS = 0.0798 * SalBruto;
                    txtAliINSS.Text = DescontoINSS.ToString();
                    
                }
                else if (SalBruto <= 1050)
                {
                    txtAliINSS.Text = "8.65%";
                    DescontoINSS = 0.0865 * SalBruto;

                }
                else if (SalBruto <= 1400.77)
                {
                    txtAliINSS.Text = "9.0%";
                    DescontoINSS = 0.09 * SalBruto;
                }
                else if (SalBruto <= 2801.56)
                {
                    txtAliINSS.Text = "11.0%";
                    DescontoINSS = 0.11 * SalBruto;
                }
                else if (SalBruto > 2801.56)
                {
                    txtAliINSS.Text = "Teto";
                }
            }
            catch (Exception)
            {

            }
        }
    }
}
