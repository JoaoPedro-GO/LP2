﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCLasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtTempo.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiaFalta.Text);

            MessageBox.Show("Nome:" + objHorista.NomeEmpregado + "\n" + "Matrícula:" + objHorista.Matricula + "\n" + "Tempo Trabalho:" + objHorista.TempoTrabalho().ToString()+ "\n" + "Salario:" + objHorista.SalarioBruto().ToString("N2"));

        }
    }
}
