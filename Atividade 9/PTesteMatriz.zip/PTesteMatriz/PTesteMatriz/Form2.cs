﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatriz
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int N = ValorN(); // Obter o valor de N conforme as regras especificadas

            string[] nomes = new string[N];
            int[] comprimentos = new int[N];

            for (int i = 0; i < N; i++)
            {
                string nome = Interaction.InputBox("Digite o nome completo da pessoa " + (i + 1) + ":");
                nomes[i] = nome;
                comprimentos[i] = nome.Replace(" ", "").Length;
            }

            listBox1.Items.Clear(); // Limpar itens existentes no ListBox
            for (int i = 0; i < N; i++)
            {
                listBox1.Items.Add("Nome: " + nomes[i] + " - Comprimento: " + comprimentos[i] + " caracteres");
            }
        }

        private int ValorN()
        {
            int ultimoDigitoRA = 3; // Substitua pelo seu último dígito do RA
            int N;

            if (ultimoDigitoRA == 0)
            {
                N = 10;
            }
            else
            {
                N = ultimoDigitoRA;
            }

            return N;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
