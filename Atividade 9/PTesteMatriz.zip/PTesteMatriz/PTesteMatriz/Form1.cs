﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um número {i+1}", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;

                }
            }
            Array.Reverse(vetor);

            auxiliar = "";

            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void bntExercicio2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[3, 3];
            string auxiliar = "";
            string saida = "";
            double media;


            for (int aluno = 0; aluno < 3; aluno++)
            {
                double somamedia = 0;
                for (int nota = 0; nota < 3; nota++)
                {

                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {aluno + 1} para a nota {nota + 1}");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]) || (notas[aluno, nota] < 0) || (notas[aluno, nota] > 10))
                    {


                        MessageBox.Show("Número inválido!");
                        nota--;

                    }
                    else
                    {
                        somamedia += notas[aluno, nota];
                    }
                }


                media = somamedia / 3;

                saida = saida + "Média do Aluno " + (aluno + 1) + ":" + media.ToString("N2") + "\n";
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
"Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            string resultado = "Alunos:\n";
            foreach (string aluno in alunos)
            {
                resultado += aluno + "\n";
            }
            MessageBox.Show(resultado);
        }

        private void btnExercico5_Click(object sender, EventArgs e)
        {
            Form2 Frm2 = new Form2();
            Frm2.Show();
        }
    }
}
