﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDisaster0030482321020
{
    public partial class FrmEvento : Form
    {
        private BindingSource bnEvento = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsEvento = new DataSet();
        private DataSet dsCidade = new DataSet();
        private DataSet dsTipo = new DataSet();

        public FrmEvento()
        {
            InitializeComponent();
        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void FrmEvento_Load(object sender, EventArgs e)
        {
            try
            {
                Evento Eve = new Evento();
                dsEvento.Tables.Add(Eve.Listar());
                bnEvento.DataSource = dsEvento.Tables["Evento"];
                dgvEvento.DataSource = bnEvento;
                bnvEvento.BindingSource = bnEvento;

                txtIdEvento.DataBindings.Add("TEXT", bnEvento, "idCidade");
                cbxNivelSeveridade.DataBindings.Add("SelectedItem", bnEvento, "nivelseveridade");
                mskbxAreaAfetada.DataBindings.Add("TEXT",)


                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];
                cbxCidade.DisplayMember = "nome";
                cbxCidade.ValueMember = "idcidade";
                cbxCidade.DataBindings.Add("SelectedValue", bnEvento, "cidade_id");
                
                Tipo Tip = new Tipo();
                dsTipo.Tables.Add(Tip.Listar());
                cbxTipo.DataSource = dsTipo.Tables["Tipo"];
                cbxTipo.DisplayMember = "descricao";
                cbxTipo.ValueMember = "idtipo";
                cbxTipo.DataBindings.Add("SelectedValue", bnEvento, "tipo_idtipo");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }


            bnEvento.AddNew();

            txtNome.Enabled = true;
            cbxUF.Enabled = true;
            cbxUF.SelectedIndex = 0;
            mskbxPopulacao.Enabled = true;

            cbxTipo.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }
    }
}
