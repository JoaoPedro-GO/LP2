﻿namespace PDisaster0030482321020
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.outrosCadastosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroCidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroTiposDeEventosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outrosCadastosToolStripMenuItem,
            this.cToolStripMenuItem,
            this.sobreToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // outrosCadastosToolStripMenuItem
            // 
            this.outrosCadastosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroCidadesToolStripMenuItem,
            this.cadastroTiposDeEventosToolStripMenuItem});
            this.outrosCadastosToolStripMenuItem.Name = "outrosCadastosToolStripMenuItem";
            this.outrosCadastosToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.outrosCadastosToolStripMenuItem.Text = "Outros Cadastos";
            this.outrosCadastosToolStripMenuItem.Click += new System.EventHandler(this.outrosCadastosToolStripMenuItem_Click);
            // 
            // cadastroCidadesToolStripMenuItem
            // 
            this.cadastroCidadesToolStripMenuItem.Name = "cadastroCidadesToolStripMenuItem";
            this.cadastroCidadesToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.cadastroCidadesToolStripMenuItem.Text = "Cadastro Cidades";
            this.cadastroCidadesToolStripMenuItem.Click += new System.EventHandler(this.cadastroCidadesToolStripMenuItem_Click);
            // 
            // cadastroTiposDeEventosToolStripMenuItem
            // 
            this.cadastroTiposDeEventosToolStripMenuItem.Name = "cadastroTiposDeEventosToolStripMenuItem";
            this.cadastroTiposDeEventosToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.cadastroTiposDeEventosToolStripMenuItem.Text = "Cadastro Tipos de Eventos";
            this.cadastroTiposDeEventosToolStripMenuItem.Click += new System.EventHandler(this.cadastroTiposDeEventosToolStripMenuItem_Click);
            // 
            // cToolStripMenuItem
            // 
            this.cToolStripMenuItem.Name = "cToolStripMenuItem";
            this.cToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.cToolStripMenuItem.Text = "Cadastro Eventos";
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.sobreToolStripMenuItem.Text = "Sobre";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip2);
            this.IsMdiContainer = true;
            this.Name = "frmPrincipal";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem outrosCadastosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroCidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroTiposDeEventosToolStripMenuItem;
    }
}